package com.example.speak_and_translate_update

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
