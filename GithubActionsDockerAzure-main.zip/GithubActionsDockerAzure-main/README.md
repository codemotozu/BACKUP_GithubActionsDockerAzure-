problems to solve:


implement hive database

advice the user to speal clearly and speak fast so the mic capture all the words wothout cutting between sentences
and also to improve speaking repeat what the app is speaking to develop a better speaking
do "shadowing" to improve pronounciation


sometimes even when i have the option "word by word in german" the app dosent detect the word by word translation 
maybe i can solve the problem implementing a local database like hive

sometime when i speak spanish dosent think is spanish

improve the mic similar to google traductor mic does, needs to be "(escuchando)" all the time

put question marks commas and points as voice command for instance : voice in spanish "signo de interrogacion" the app detects it as "?"


sometimes the "word by word pronunciation" is incomplete

The voices from speak and translate should have an option to slow ,normal and fast pronounciation


below "word for word translation" give the option to the user to listen

A1-A2 Vocabulary [x]

B1-B2 Vocabulary [x]

C1-C2 Vocabulary [x]



besides native,colloquial, informal and formal add this new feature : the most identical translation



if the user is mid advance and let say want to start speaking in the language of learning not the mother tongue and the choice was  german make sure YOU correct the user if he or she Make a german grammatical mistake
